import './App.css';
import React from "react";
// import AddProduct from './components/AddProduct';
// import ListProducts from './components/ListProducts';
import { Link, NavLink } from "react-router-dom"

function App() {
  return (
    <nav className='nav navbar'>
      <ul className='navbar-nav'>
        <li className='nav-item'><NavLink activeClassName="active" className="nav-link" to="/list-products">Product List</NavLink></li>
        <li className='nav-item'><NavLink activeClassName="active" className="nav-link" to="/add-products">Add Product</NavLink></li>
      </ul>
    </nav>

  );
}

export default App;
