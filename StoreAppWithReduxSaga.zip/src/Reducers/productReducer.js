function productReducer(state = { products: [], fecthIsLoading:false }, action) {
    switch (action.type) {
        case 'ADD_PRODUCT':
            state.products = state.products.concat(action.product)
            return {
                ...state,
                products: [...state.products],
                fecthIsLoading: false
            }
        case 'DELETE_PRODUCT':
            state.products = state.products.filter((product) => product.id !== action.id)
            return {
                ...state,
                products: [...state.products],
                fecthIsLoading: false
            }
        case 'LOADING_FETCH_PRODUCTS':
            return {
                ...state,
                products: [...state.products],
                fecthIsLoading: true
            }
        case 'FETCH_PRODUCTS':
            //    return action.products;
            return {
                ...state,
                products: action.products,
                fecthIsLoading: false
            }
        default:
            return state
    }

}
export default productReducer;