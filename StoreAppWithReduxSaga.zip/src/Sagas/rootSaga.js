
import {takeEvery} from 'redux-saga/effects';
import {fecthProductAsync,addProductAsync, deleteProductAsync} from '../Sagas/productSagas'

export default function* rootSaga(){
    yield takeEvery('START_FETCH_PRODUCT', fecthProductAsync) ;
    yield takeEvery('START_ADD_PRODUCT', addProductAsync) ;
    yield takeEvery('START_DELETE_PRODUCT', deleteProductAsync) ;
}