import axios from 'axios';
import {  put, call } from 'redux-saga/effects';
import { loadingFetchProduct,fetchProductsSuccess,addProductSuccess, deleteProductSuccess } from '../Actions/ProductActions';

// export default function* watchFetchProducts() {
//     yield takeEvery('START_FETCH_PRODUCT', fecthProductAsync)
// }

export  function* fecthProductAsync() {
    yield put(loadingFetchProduct());

    const response = yield call(() => {
        return axios.get('http://localhost:3000/products')
    })
    yield put(fetchProductsSuccess(response.data));
}
export function* addProductAsync(action) {
    const response = yield call(() => {
        return axios.post('http://localhost:3000/products' ,action.product)
    })
    if(response.status === 201){
        yield put(addProductSuccess(response.data));
    }
}
export function* deleteProductAsync(action) {
    const response = yield call(() => {
        return axios.delete('http://localhost:3000/products/' +action.id)
    })
    if(response.status === 200){
        yield put(deleteProductSuccess(action.id));
        
    }
}
