import React from "react";
import { connect } from "react-redux";
import { startDeletingProduct } from '../Actions/ProductActions';


class ProductRow extends React.Component {

    constructor() {
        super();
        this.deleteProduct = this.deleteProduct.bind(this)

    }

    deleteProduct() {
        this.props.startDeletingProduct(this.props.product.id)
    }


    render() {
        return (
            <tr>
                <td>{this.props.product.id}</td>
                <td>{this.props.product.name}</td>
                <td>{this.props.product.price}</td>
                <td>{this.props.product.location}</td>
                <td>
                    {/* <button className="btn btn-primary" onClick={editProduct}>Add Product</button> */}
                    <button className="btn btn-danger" onClick={this.deleteProduct}>Delete</button>
                </td>
            </tr>
        )
    }
}

const mapStateToProps = (state) => {
    return {}
}
const mapDispatchToProps = (dispatch) => {
    return {
        startDeletingProduct: (id) => dispatch(startDeletingProduct(id))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(ProductRow);