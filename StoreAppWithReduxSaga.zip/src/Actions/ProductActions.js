// import axios from "axios"
// setting up the action creators
// export const fetchProducts = () => {
//     return (dispatch) => {
//         dispatch({ type: 'LOADING_FETCH_PRODUCTS' })
//         axios.get('http://localhost:3000/products')
//             .then(response => {
//                 return response.data
//             })
//             .then(responseJSON => {
//                 dispatch({ type: 'FETCH_PRODUCTS', products: responseJSON })
//             })
//             .catch(error => {
//                 console.log(error)
//             })
//     }
// }

export const startFetchProducts = ()=>{
    return {type:'START_FETCH_PRODUCT'}
}
export const loadingFetchProduct = ()=>{
    return {type:'LOADING_FETCH_PRODUCTS'}
}
export const fetchProductsSuccess = (data)=>{
    console.log("success call")
    return {type:'FETCH_PRODUCTS',products:data}
}


// export const deleteProduct = (id) =>{
//     return (dispatch)=>{
//         axios.delete('http://localhost:3000/products/'+ id)
//         .then(response=>{
//             if(response.status === 200){
//                 dispatch({
//                     type:"DELETE_PRODUCT",
//                     id:id
//                 })
//             }
//         })
//         .catch(error=>console.log(error))
//     }
// }
export const startAddingProduct = (data)=>{
    return {type:'START_ADD_PRODUCT',product:data}
}
export const addProductSuccess = (data)=>{
    return {type:'ADD_PRODUCT',product:data}
}
export const startDeletingProduct = (id)=>{
    return {type:'START_DELETE_PRODUCT',id:id}
}
export const deleteProductSuccess = (id)=>{
    return {type:'DELETE_PRODUCT',id:id}
}
// export const addProduct = (data)=>{
//     return (dispatch)=>{
//         axios.post('http://localhost:3000/products', data)
//         .then(response=>{
//            if(response.status === 201){
//                dispatch({
//                    type:'ADD_PRODUCT',
//                    products:JSON.stringify(response.data)
//                })   
//            }
//         })
//         .catch(error=>console.log(error))

//     }
// }