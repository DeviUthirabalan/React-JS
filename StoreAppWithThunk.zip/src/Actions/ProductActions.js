import axios from 'axios';

// setting up the action creators
export const fetchProducts = () => {
    return (dispatch) => {
        dispatch({ type: 'LOADING_FETCH_PRODUCTS' })
        axios.get('http://localhost:3000/products')
            .then(response => {
                return response.data
            })
            .then(responseJSON => {
                dispatch({ type: 'FETCH_PRODUCTS', products: responseJSON })
            })
            .catch(error => {
                console.log(error)
            })
    }
}

export const deleteProduct = (id) =>{
    return (dispatch)=>{
        axios.delete('http://localhost:3000/products/'+ id)
        .then(response=>{
            if(response.status === 200){
                dispatch({
                    type:"DELETE_PRODUCT",
                    id:id
                })
            }
        })
        .catch(error=>console.log(error))
    }
}

export const addProduct = (data)=>{
    return (dispatch)=>{
        axios.post('http://localhost:3000/products', data)
        .then(response=>{
           if(response.status === 201){
               dispatch({
                   type:'ADD_PRODUCT',
                   products:JSON.stringify(response.data)
               })   
           }
        })
        .catch(error=>console.log(error))

    }
}