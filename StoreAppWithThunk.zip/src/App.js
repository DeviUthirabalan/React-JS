import './App.css';
import React from "react";
// import AddProduct from './components/AddProduct';
// import ListProducts from './components/ListProducts';
import { Link } from "react-router-dom"

function App() {
  return (
    <nav className='nav navbar'>
      <ul className='navbar-nav'>
        <li className='nav-item'><Link className="nav-link" to="/list-products">Product List</Link></li>
        <li className='nav-item'><Link className="nav-link" to="/add-products">Add Product</Link></li>
      </ul>
    </nav>

  );
}

export default App;
