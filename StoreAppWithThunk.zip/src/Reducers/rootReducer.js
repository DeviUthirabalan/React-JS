import {combineReducers} from 'redux'
import productReducer from './productReducer'

// export const rootReducer = combineReducers({
//     productReducer
// })
export const rootReducer = combineReducers({
    // Define a top-level state field named `todos`, handled by `todosReducer`
    productReducer: productReducer
    // filters: filtersReducer
  })