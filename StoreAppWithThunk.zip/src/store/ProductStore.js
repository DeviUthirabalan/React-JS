import { applyMiddleware, legacy_createStore as createStore} from 'redux'
import { rootReducer } from '../Reducers/rootReducer';
import thunk from 'redux-thunk'
// import productReducer from '../Reducers/productReducer';
// import loggingMiddleware from '../Middlewares/loggingMiddleware';
// import fetchProductsMiddleware from '../Middlewares/fetchProductsMiddleware'

// let productStore = createStore(rootReducer,applyMiddleware(loggingMiddleware,fetchProductsMiddleware))
let productStore = createStore(rootReducer,applyMiddleware(thunk))



// selectors-------------
// export const getProducts = state => {
//     return state.productReducer
// }

export default productStore;