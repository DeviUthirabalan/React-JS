
export const productSelectors = {
    getProducts : state => state.productReducer.products,
    getLoadingStatus:state=>state.productReducer.fecthIsLoading
}