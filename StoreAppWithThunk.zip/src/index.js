import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter,Routes, Route} from "react-router-dom";
import ListProducts from './components/ListProducts';
import AddProduct from './components/AddProduct';
import { Provider } from 'react-redux';
import productStore from './store/ProductStore';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={productStore}>
  <BrowserRouter>
  <App/>
  <Routes>
    <Route path="/list-products" element={<ListProducts />} />
    <Route path="/add-products" element={<AddProduct />} />
  </Routes>
</BrowserRouter>
</Provider>




);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
