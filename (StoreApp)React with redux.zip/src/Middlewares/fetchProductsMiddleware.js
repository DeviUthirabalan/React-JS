import axios from 'axios';

const fetchProductsMiddleware = (store)=>(next)=>(action)=>{
    if(action.type === 'FETCH_PRODUCT'){
           axios.get('http://localhost:3000/products')
         .then(response=>{
            action.products = response.data
            next(action)
         })
         .catch(error=>{
            console.log(error)
         })
    }
    else{
        next(action)
    }

 

}

export default fetchProductsMiddleware;