import React from "react";
// import axios from "axios";
import ProductRow from "../components/ProductRow";
import {connect} from "react-redux";
import {productSelectors} from '../selectors/productSelectors'



class ListProducts extends React.Component {
    // constructor(){
    //     super();
    //     this.state={
    //         products:[]
    //     }
    // }

    // componentWillMount(){
    //     axios.get('http://localhost:3000/products')
    //     .then(response=>{
    //         if(response.status === 200){
    //             this.props.dispatch({
    //                 type:'FETCH_PRODUCT',
    //                 products:response.data
    //             })
    //         }
            
    //         // this.setState({products:response.data})
    //     })
    //     .catch(error=>{
    //         console.log(error)
    //     }
    //     )
    // }

    componentDidMount(){
        this.props.dispatch({
            type:'FETCH_PRODUCT'
        })
    }

    render(){
        return(
            <div className="m-10 p-10">
                <table className="table table-light table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>product</th>
                        <th>price</th>
                        <th>location</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    {this.props.products.map((product,index)=>{
                    //    return <tr>
                    //         <td>{index}</td>
                    //         <td>{product.id}</td>
                    //         <td>{product.name}</td>
                    //         <td>{product.price}</td>
                    //         <td>{product.location}</td>
                    //     </tr>
                       return <ProductRow product={product} key={index}/>
                    })}
                    </tbody>
                </table>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return{
        products :productSelectors.getProducts(state)
    }
}
export default connect(mapStateToProps)(ListProducts);