import React from "react";
import axios from "axios";
import { connect } from "react-redux";

class AddProduct extends React.Component{
    constructor(){
        super();
        this.state={
            id:'',
            name:'',
            price:'',
            location:''
        }
        this.changeId = this.changeId.bind(this);
        this.changeName = this.changeName.bind(this);
        this.changePrice = this.changePrice.bind(this);
        this.changeLocation = this.changeLocation.bind(this);   
        this.addProduct = this.addProduct.bind(this)
    }

changeId(event){
    console.log(event.target.value)
    this.setState({id:event.target.value})
}
changeName(event){
    this.setState({name:event.target.value})
}
changePrice(event){
    this.setState({price:event.target.value})
}
changeLocation(event){
    this.setState({location:event.target.value})
}

addProduct(event){
    console.log("product added")
    event.preventDefault()
    let data = {
        "id":this.state.id,
        "name":this.state.name,
        "price":this.state.price,
        "location":this.state.location,
    }
    axios.post('http://localhost:3000/products', data)
         .then(response=>{
            if(response.status === 200){
                this.props.dispatch({
                    type:'ADD_PRODUCT',
                    product:response.data
                })
                // this.ref.addFormData.reset()
            }
         })
         .catch(error=>console.log(error))
}

render(){
    return(
        <form onSubmit={this.addProduct} ref="addFormData">
        <div className="form-group">
            <label className="form-label">ID</label>
            <input type="text" name='id' onChange={this.changeId}  className="form-control" ></input>
        </div>
        <div className="form-group">
            <label>Name</label>
            <input type="text" name='name' onChange={this.changeName}  className="form-control" ></input>
        </div>  
        <div className="form-group">
            <label>Price</label>
            <input type="text" name='price' className="form-control" onChange={this.changePrice} ></input>
        </div>
        <div className="form-group">
            <label>Location</label>
            <input type="text" name='location' className="form-control" onChange={this.changeLocation} ></input>
        </div>
        <div className="form-group text-center">
          <button type="submit" className="btn btn-success">Add Product</button>  
        </div>
        </form>
    )
}
}
export default connect()(AddProduct);