import axios from "axios";
import React from "react";
import { connect } from "react-redux";

class ProductRow extends React.Component{

    constructor(){
        super();
        this.deleteProduct = this.deleteProduct.bind(this)

    }

    deleteProduct(){
        axios.delete('http://localhost:3000/products/'+ this.props.product.id)
            .then(response=>{
                if(response.status === 200){
                    this.props.dispatch({
                        type:"DELETE_PRODUCT",
                        id:this.props.product.id
                    })
                }
            })
            .catch(error=>console.log(error))
    }


    render(){
        return(
            <tr>
                <td>{this.props.product.id}</td>
                <td>{this.props.product.name}</td>
                <td>{this.props.product.price}</td>
                <td>{this.props.product.location}</td>
                <td>
                    {/* <button className="btn btn-primary" onClick={editProduct}>Add Product</button> */}
                    <button className="btn btn-danger" onClick={this.deleteProduct}>Delete</button>
                </td>
            </tr>
        )
    }
}
export default connect()(ProductRow);