
export const productSelectors = {
    getProducts : state => state.productReducer
}